import os, json, bcrypt, psycopg2, pyotp

def handle(event, context):
    try:
        body = json.loads(event.body.decode('utf-8'))
        email = body.get("email"); pwd = body.get("password"); code_totp = body.get("code_totp")
        if not email or not pwd or not code_totp:
            return json.dumps({"error":"email, mot de passe ou code 2FA manquant"}), 400

        conn = psycopg2.connect(
            host=os.getenv("DB_HOST"), port=os.getenv("DB_PORT"),
            user=os.getenv("DB_USER"), password=os.getenv("DB_PASS"),
            dbname=os.getenv("DB_NAME")
        )
        cur = conn.cursor()
        cur.execute("SELECT password, twofa_secret FROM users WHERE email=%s;", (email,))
        row = cur.fetchone()
        if not row:
            cur.close(); conn.close()
            return json.dumps({"error":"email ou mot de passe invalide"}), 401

        password_hash, twofa_secret = row
        if not bcrypt.checkpw(pwd.encode(), password_hash.encode()):
            cur.close(); conn.close()
            return json.dumps({"error":"mot de passe invalide"}), 401

        totp = pyotp.TOTP(twofa_secret)
        if not totp.verify(code_totp, valid_window=1):
            cur.close(); conn.close()
            return json.dumps({"error":"code 2FA invalide ou expiré"}), 401

        cur.close(); conn.close()
        return json.dumps({"status":"login-success"}), 200

    except Exception as e:
        return json.dumps({"error":str(e)}), 500
