import os, json, io, bcrypt, psycopg2, qrcode, pyotp
from base64 import b64encode
from datetime import datetime, timezone, timedelta

EXPIRATION_DELTA = timedelta(minutes=1)  # debug

def handle(event, context):
    try:
        body = json.loads(event.body.decode('utf-8'))
        email = body.get("email"); pwd = body.get("password")
        if not email or not pwd:
            return json.dumps({"error": "email ou mot de passe manquant"}), 400

        conn = psycopg2.connect(
            host=os.getenv("DB_HOST"), port=os.getenv("DB_PORT"),
            user=os.getenv("DB_USER"), password=os.getenv("DB_PASS"),
            dbname=os.getenv("DB_NAME")
        )
        cur = conn.cursor()
        cur.execute(
            """SELECT password, twofa_secret, password_generated_at
               FROM users WHERE email=%s;""",
            (email,)
        )
        row = cur.fetchone()
        if not row:
            cur.close(); conn.close()
            return json.dumps({"error":"email ou mot de passe invalide"}), 401

        password_hash, twofa_secret, pwd_gen_at = row

        if not bcrypt.checkpw(pwd.encode(), password_hash.encode()):
            cur.close(); conn.close()
            return json.dumps({"error":"email ou mot de passe invalide"}), 401

        now_utc = datetime.now(timezone.utc)

        # Harmonisation fuseau
        if pwd_gen_at.tzinfo is None or pwd_gen_at.tzinfo.utcoffset(pwd_gen_at) is None:
            pwd_gen_at = pwd_gen_at.replace(tzinfo=timezone.utc)

        if now_utc - pwd_gen_at > EXPIRATION_DELTA:
            cur.close(); conn.close()
            return json.dumps({
                "status": "password-expired",
                "email": email,
                "password_created_at": pwd_gen_at.isoformat(),
                "now_utc": now_utc.isoformat()
            }), 200

        totp = pyotp.TOTP(twofa_secret)
        code_totp = totp.now()

        qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M)
        qr.add_data(code_totp); qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO(); img.save(buf, format="PNG")
        qr_base64 = b64encode(buf.getvalue()).decode("utf-8")

        cur.close(); conn.close()
        return json.dumps({
            "status":"password-validated",
            "email": email,
            "code_totp": code_totp,
            "qr_otp_base64": qr_base64,
            "password_created_at": pwd_gen_at.isoformat(),
            "now_utc": now_utc.isoformat()
        }), 200

    except Exception as e:
        return json.dumps({"error": str(e)}), 500
