# openfaas-functions/renew-password/handler.py
import os, json, io, string, random, bcrypt, psycopg2, qrcode
from base64 import b64encode
from qrcode.image.pil import PilImage  # ← NEW

def handle(event, context):
    try:
        body  = json.loads(event.body.decode("utf-8"))
        email = body.get("email")
        if not email:
            return json.dumps({"error": "email manquant"}), 400

        # Nouveau mot de passe
        charset = string.ascii_letters + string.digits + string.punctuation
        plain_password = "".join(random.choice(charset) for _ in range(24))
        hashed_password = bcrypt.hashpw(
            plain_password.encode(), bcrypt.gensalt()
        ).decode()

        # Connexion PG
        conn = psycopg2.connect(
            host=os.getenv("DB_HOST", "my-postgres-postgresql.db.svc.cluster.local"),
            port=os.getenv("DB_PORT", "5432"),
            user=os.getenv("DB_USER", "postgres"),
            password=os.getenv("DB_PASS", ""),
            dbname=os.getenv("DB_NAME", "usersdb"),
        )
        cur = conn.cursor()

        # Update + horodatage
        cur.execute(
            """
            UPDATE users
            SET password = %s,
                password_generated_at = NOW()
            WHERE email = %s
            RETURNING id;
            """,
            (hashed_password, email),
        )
        if not cur.fetchone():
            cur.close(); conn.close()
            return json.dumps({"error": "utilisateur inexistant"}), 404
        conn.commit()

        # QR code (PIL)
        qr = qrcode.QRCode(
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            image_factory=PilImage,          # ← use PIL, supports format=...
        )
        qr.add_data(plain_password); qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        buf = io.BytesIO()
        img.save(buf, format="PNG")         # plus d’erreur
        qr_password_base64 = b64encode(buf.getvalue()).decode("utf-8")

        cur.close(); conn.close()
        return json.dumps({
            "status": "password-reset",
            "password": plain_password,
            "qr_password_base64": qr_password_base64,
        }), 200

    except Exception as e:
        return json.dumps({"error": str(e)}), 500
