import os
import json
import io
import random
import string
import bcrypt
import psycopg2
import qrcode
import pyotp
from base64 import b64encode

# Longueur du mot de passe généré
PWD_LEN = 24
CHARSET = string.ascii_letters + string.digits + string.punctuation

def handle(event, context):
    try:
        # -------- 1. Lecture de la requête --------
        body = json.loads(event.body.decode('utf-8'))
        email = body.get("email")
        if not email:
            return json.dumps({"error": "email manquant"}), 400

        # -------- 2. Génération du mot de passe --------
        plain_password = ''.join(random.choice(CHARSET) for _ in range(PWD_LEN))

        # -------- 3. Hash bcrypt --------
        salt = bcrypt.gensalt()
        hashed_password = bcrypt.hashpw(
            plain_password.encode('utf-8'),
            salt
        ).decode('utf-8')

        # -------- 4. Secret TOTP --------
        twofa_secret = pyotp.random_base32()

        # -------- 5. Connexion PostgreSQL --------
        conn = psycopg2.connect(
            host=os.getenv("DB_HOST", "my-postgres-postgresql.db.svc.cluster.local"),
            port=os.getenv("DB_PORT", "5432"),
            user=os.getenv("DB_USER", "postgres"),
            password=os.getenv("DB_PASS", ""),
            dbname=os.getenv("DB_NAME", "usersdb")
        )
        cur = conn.cursor()

        # -------- 6. Insertion utilisateur --------
        cur.execute("""
            INSERT INTO users (
                email,
                password,
                twofa_secret,
                twofa_enabled,
                password_generated_at        -- nouvelle colonne
            )
            VALUES (%s, %s, %s, TRUE, NOW())     -- NOW() = date de création
            RETURNING id;
        """, (email, hashed_password, twofa_secret))
        user_id = cur.fetchone()[0]
        conn.commit()

        # -------- 7. QR code mot de passe --------
        qr1 = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M)
        qr1.add_data(plain_password)
        qr1.make(fit=True)
        img1 = qr1.make_image(fill_color="black", back_color="white")
        buf1 = io.BytesIO()
        img1.save(buf1, format="PNG")
        qr_password_base64 = b64encode(buf1.getvalue()).decode("utf-8")

        # -------- 8. QR code URI TOTP --------
        issuer = "MonApp"
        totp_uri = pyotp.totp.TOTP(twofa_secret).provisioning_uri(
            name=email, issuer_name=issuer
        )
        qr2 = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M)
        qr2.add_data(totp_uri)
        qr2.make(fit=True)
        img2 = qr2.make_image(fill_color="black", back_color="white")
        buf2 = io.BytesIO()
        img2.save(buf2, format="PNG")
        qr_2fa_base64 = b64encode(buf2.getvalue()).decode("utf-8")

        # -------- 9. Fermeture connexion --------
        cur.close()
        conn.close()

        # -------- 10. Réponse --------
        return json.dumps({
            "status": "user-created",
            "email": email,
            "password": plain_password,
            "qr_password_base64": qr_password_base64,
            "twofa_secret": twofa_secret,
            "qr_2fa_base64": qr_2fa_base64
        }), 200

    except Exception as e:
        return json.dumps({"error": str(e)}), 500
